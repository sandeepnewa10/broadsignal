<div class="entry-meta">
        <?php grand_popo_posted_on(); ?>
</div>