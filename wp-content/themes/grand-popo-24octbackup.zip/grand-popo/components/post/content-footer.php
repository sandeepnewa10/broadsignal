	<footer class="entry-footer">
		<?php grand_popo_entry_footer(); ?>
	</footer><!-- .entry-footer -->