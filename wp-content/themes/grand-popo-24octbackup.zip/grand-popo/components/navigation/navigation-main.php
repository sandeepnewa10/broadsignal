<nav id="site-navigation" class="main-navigation " >
    <?php wp_nav_menu(array('theme_location' => 'main-menu', 'menu_id' => 'main-menu', 'fallback_cb' => 'wp_page_menu', 'container_class' => 'main-menu-container')); ?>
</nav>
