 
(function (jQuery) {
    window.$ = jQuery.noConflict();
})(jQuery);


